export {default as Login} from "./pages/Login";
export {default as Register} from "./pages/Register";
export {default as Home} from "./pages/Home";
export {default as Create} from "./pages/Create";
export {default as List} from "./pages/List";
export {default as Update} from "./pages/Update";
export {default as Holiday} from "./pages/Holiday";
export {default as Profile} from "./pages/Profile";