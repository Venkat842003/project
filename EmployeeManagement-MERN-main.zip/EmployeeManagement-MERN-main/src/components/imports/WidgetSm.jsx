import React from 'react'
import "./widgetSm.css"

export default function WidgetSm() {
    return (
        <div className="widgetSm">
            {/* <h1>small</h1> */}
        </div>
    )
}
