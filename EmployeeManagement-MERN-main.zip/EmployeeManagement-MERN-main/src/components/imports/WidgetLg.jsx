import React from 'react'
import "./widgetLg.css"

export default function WidgetLg() {
    return (
        <div className="widgetLg">
            {/* <h1>large</h1> */}
        </div>
    )
}
